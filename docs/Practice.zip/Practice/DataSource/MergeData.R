#####################################################################
# Date: 2018/8/10
# Task: Merge and annotate OSK iPS data
# Reference Version: GRCm38.90
# @author: Lihui Lin
#####################################################################
options(stringsAsFactors = F)
# 1. Merge results of rsem ####
setwd("F:/���ƴ�/GIBH������ѵ/RNAseq/Practise/DataSource")
raw_data <- "./mmv86" # the fold that store *genes.results
anno_data <- "../Annotation/Ensembl_v86.csv" # the file that contain ENSG id and Gene symbol
output_name <- "osk"

counts <- list()
tpm <- list()

for (f in list.files(raw_data)){
  id <- strsplit(f,".", fixed=TRUE)[[1]][1]
  cat(id, "\n")
  temp <- read.table(file.path(raw_data,f), header = TRUE, check.names = FALSE)
  counts[[id]] <- temp$expected_count
  tpm[[id]] <- temp$TPM
}

counts_df <- as.data.frame(counts, row.names = temp$gene_id)
counts_df <- counts_df[!duplicated(rownames(counts_df)),]

tpm_df <- as.data.frame(tpm, row.names = temp$gene_id)
tpm_df <- tpm_df[!duplicated(rownames(tpm_df)),]

# 2. Annotated the ENSG_ids with Gene symbols ####
gene_anno <- read.csv(anno_data, header = TRUE, row.names = 1, check.names = F)

## remove duplicated symbol
ensg2symbol <- gene_anno[rownames(counts_df),'Associated Gene Name']
sum(is.na(ensg2symbol))
mask <- !duplicated(ensg2symbol)

counts_anno <- counts_df[mask,]
rownames(counts_anno) <- ensg2symbol[mask]
counts_anno <- counts_anno[complete.cases(rownames(counts_anno)),]

tpm_anno <- tpm_df[mask,]
rownames(tpm_anno) <- ensg2symbol[mask]
tpm_anno <- tpm_anno[complete.cases(rownames(tpm_anno)),]

## 3. save data
write.csv(counts_anno, paste0(output_name,"_count.csv"))
write.csv(tpm_anno, paste0(output_name,"_tpm.csv"))


